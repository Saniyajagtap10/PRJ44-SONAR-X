# PRJ-44 — AUV Side-Scan Sonar Hazard Classification Engine

Complete project package for the PRJ-44 deconvolutional feature de-noising CNN.

## Included
- app.py — premium Streamlit research dashboard
- model.py — SonarDeconvCNN architecture
- dataset_utils.py — safe dataset discovery and annotation parsing
- train.py — actual training/evaluation pipeline
- requirements.txt
- run_web.bat
- train_model.bat
- config.json
- results/ — recorded evaluation artifacts from the completed run
- models/ — place the trained checkpoint `sonar_prj44.pth` here

## Important
The trained checkpoint is a binary file created on the machine where training was executed. It was not attached to this ChatGPT workspace, so this package does NOT fabricate a replacement checkpoint. The web app will correctly report that the model is unavailable until the real checkpoint is present.

If the checkpoint is available on the original PC, copy it to:
models\\sonar_prj44.pth

The recorded run completed 12 epochs and produced a test accuracy of 71.43% on 21 test samples. The measured SNR change was -0.25 dB, so the dashboard does not falsely present a positive denoising improvement.
