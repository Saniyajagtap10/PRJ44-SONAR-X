@echo off
cd /d "%~dp0"
echo ==============================================
echo PRJ-44 Novelty Backend Training
 echo ==============================================
python train.py
if errorlevel 1 (
  echo.
  echo TRAINING FAILED. Read the error above.
  pause
  exit /b 1
)
echo.
echo ==============================================
echo TRAINING COMPLETED SUCCESSFULLY
 echo Proposed model + baseline comparison created.
echo Web UI has NOT been changed.
echo ==============================================
pause
