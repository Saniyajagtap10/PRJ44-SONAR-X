@echo off
title PRJ-44 SONAR WEB
echo ==========================================
echo PRJ-44 SONAR HAZARD CLASSIFICATION WEB
echo ==========================================
py -m pip install -r requirements.txt
py -m streamlit run app.py
pause
